package com.example.capri

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.transition.TransitionManager
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Панель сверху экрана («остров»): персонаж, статус, процент заряда.
 * Тап — слушает вопрос, долгое нажатие — открывает настройки.
 * Реагирует на открытие приложений и на фразу «Капри ответ».
 */
class OverlayService : Service(), VoiceEngine.Listener {

    companion object {
        @Volatile
        var running = false
        private const val CHANNEL = "capri"
        private const val NOTIF_ID = 17
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var settings: Settings
    private lateinit var params: WindowManager.LayoutParams

    private lateinit var root: LinearLayout
    private lateinit var avatar: CharacterView
    private lateinit var title: TextView
    private lateinit var detail: TextView
    private lateinit var battery: TextView

    private var voice: VoiceEngine? = null
    private var voiceBusy = false
    private var batteryPct = -1
    private var charging = false
    private var attached = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        applyStyle()
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            batteryPct = if (level < 0) -1 else level * 100 / scale
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            updateBattery()
        }
    }

    private val resetRunnable = Runnable { showIdle() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settings = Settings(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        val canOverlay = android.provider.Settings.canDrawOverlays(this)
        if (!micOk || !canOverlay) {
            stopSelf()
            return
        }

        startAsForeground()
        buildPanel()
        applyStyle()
        showIdle()

        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        settings.prefs.registerOnSharedPreferenceChangeListener(prefListener)
        Bus.onAppOpened = { pkg -> main.post { onAppOpened(pkg) } }

        voice = VoiceEngine(this, settings, this).also { it.start() }
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        running = false
        Bus.onAppOpened = null
        main.removeCallbacksAndMessages(null)
        voice?.stop()
        voice = null
        try {
            unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {
        }
        if (::settings.isInitialized) {
            settings.prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        }
        if (attached) {
            try {
                wm.removeView(root)
            } catch (_: Exception) {
            }
            attached = false
        }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- foreground

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Капри", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Капри работает")
            .setContentText("Скажите «${settings.wakePhrase}»")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------------------------------------------------------------- панель

    private fun buildPanel() {
        avatar = CharacterView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
        }
        title = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 1
        }
        detail = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(0xFFCCCCDD.toInt())
            maxWidth = dp(230)
            visibility = View.GONE
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), 0, dp(8), 0)
            addView(title)
            addView(detail)
        }
        battery = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(5), dp(14), dp(5))
            addView(avatar)
            addView(column)
            addView(battery)
            setOnClickListener {
                avatar.bounce()
                voice?.listenNow()
            }
            setOnLongClickListener {
                startActivity(
                    Intent(this@OverlayService, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                true
            }
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(settings.panelY)
        }
        wm.addView(root, params)
        attached = true
    }

    /** Применяет цвета и положение из настроек (вызывается при любом их изменении). */
    private fun applyStyle() {
        if (!attached) return
        avatar.skin = settings.skin
        avatar.hair = settings.hair
        avatar.outfit = settings.outfit
        avatar.accent = settings.accent
        root.background = GradientDrawable().apply {
            cornerRadius = dpf(26f)
            setColor(settings.panelColor)
            setStroke(dp(1), settings.accent)
        }
        battery.setTextColor(settings.accent)
        params.y = dp(settings.panelY)
        try {
            wm.updateViewLayout(root, params)
        } catch (_: Exception) {
        }
        if (!voiceBusy) showIdle()
        updateBattery()
    }

    private fun updateBattery() {
        if (!attached) return
        battery.text = if (batteryPct < 0) "" else (if (charging) "⚡" else "") + "$batteryPct%"
    }

    // ---------------------------------------------------------------- состояния

    private fun setPanel(mood: CharacterView.Mood, titleText: String, detailText: String?) {
        if (!attached) return
        TransitionManager.beginDelayedTransition(root)
        avatar.mood = mood
        title.text = titleText
        if (detailText.isNullOrBlank()) {
            detail.visibility = View.GONE
        } else {
            detail.text = detailText
            detail.visibility = View.VISIBLE
        }
    }

    private fun showIdle() {
        main.removeCallbacks(resetRunnable)
        setPanel(CharacterView.Mood.IDLE, settings.name, null)
    }

    override fun onState(state: VoiceEngine.State, text: String?) {
        main.removeCallbacks(resetRunnable)
        when (state) {
            VoiceEngine.State.WAKE -> {
                voiceBusy = false
                showIdle()
            }
            VoiceEngine.State.LISTENING -> {
                voiceBusy = true
                avatar.bounce()
                setPanel(CharacterView.Mood.LISTENING, "Слушаю…", null)
            }
            VoiceEngine.State.THINKING -> {
                voiceBusy = true
                setPanel(CharacterView.Mood.IDLE, "Думаю…", text)
            }
            VoiceEngine.State.SPEAKING -> {
                voiceBusy = true
                setPanel(CharacterView.Mood.TALKING, settings.name, text)
            }
            VoiceEngine.State.ERROR -> {
                voiceBusy = false
                setPanel(CharacterView.Mood.IDLE, settings.name, text)
            }
        }
    }

    private fun onAppOpened(pkg: String) {
        if (voiceBusy || !attached) return
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            pkg
        }
        avatar.bounce()
        setPanel(CharacterView.Mood.HAPPY, label, "Приложение открыто")
        main.postDelayed(resetRunnable, 2500)
    }
}
