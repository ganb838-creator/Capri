package com.example.capri

import android.content.Context

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

/** Простая шина: Accessibility-служба сообщает панели, что открыто новое приложение. */
object Bus {
    @Volatile
    var onAppOpened: ((String) -> Unit)? = null
}
