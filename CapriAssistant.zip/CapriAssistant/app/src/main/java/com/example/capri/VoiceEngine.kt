package com.example.capri

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Голосовой движок: постоянно слушает, ждёт фразу «Капри ответ»,
 * затем принимает вопрос, отвечает голосом и снова уходит в ожидание.
 *
 * Все публичные методы вызываются из главного потока.
 */
class VoiceEngine(
    private val context: Context,
    private val settings: Settings,
    private val listener: Listener
) {

    enum class State { WAKE, LISTENING, THINKING, SPEAKING, ERROR }

    interface Listener {
        fun onState(state: State, text: String?)
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var running = false
    private var awaitingCommand = false
    private var busy = false // идёт обработка/озвучивание ответа

    fun start() {
        if (running) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            listener.onState(State.ERROR, "На устройстве нет службы распознавания речи")
            return
        }
        running = true
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale("ru", "RU")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { main.post { finishAnswer() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { finishAnswer() } }
                })
            }
        }
        listener.onState(State.WAKE, null)
        listen()
    }

    fun stop() {
        running = false
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    /** Касание по панели: сразу слушаем вопрос без кодовой фразы. */
    fun listenNow() {
        if (!running || busy) return
        awaitingCommand = true
        beep()
        listener.onState(State.LISTENING, null)
        listen()
    }

    // ---------------------------------------------------------------- распознавание

    private fun listen() {
        if (!running || busy) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).also {
            it.setRecognitionListener(recognitionListener)
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        recognizer?.startListening(intent)
    }

    private fun restartSoon(delay: Long = 350) {
        if (!running || busy) return
        main.postDelayed({ listen() }, delay)
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            if (busy || awaitingCommand) return
            val list = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
            checkWake(list, partial = true)
        }

        override fun onResults(results: Bundle?) {
            if (busy) return
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (list.isNullOrEmpty()) {
                afterSilence()
                return
            }
            if (awaitingCommand) {
                awaitingCommand = false
                answer(list[0])
            } else if (!checkWake(list, partial = false)) {
                restartSoon()
            }
        }

        override fun onError(error: Int) {
            if (busy) return
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                running = false
                listener.onState(State.ERROR, "Нет разрешения на микрофон")
                return
            }
            afterSilence(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 350)
        }
    }

    private fun afterSilence(delay: Long = 350) {
        if (awaitingCommand) {
            // Вопрос так и не прозвучал — возвращаемся к ожиданию кодовой фразы.
            awaitingCommand = false
            listener.onState(State.WAKE, null)
        }
        restartSoon(delay)
    }

    // ---------------------------------------------------------------- кодовая фраза

    private fun norm(s: String) = s.lowercase(Locale("ru")).replace('ё', 'е').trim()

    /** Возвращает true, если кодовая фраза найдена и обработана. */
    private fun checkWake(variants: List<String>, partial: Boolean): Boolean {
        for (v in variants) {
            val wake = parseWake(norm(v)) ?: continue
            // По промежуточному результату реагируем только на полную фразу «Капри ответ»:
            // команда вроде «Капри следующее» ждёт окончания речи.
            if (partial && !wake.full) continue
            val rest = wake.rest
            busy = false
            recognizer?.cancel()
            if (rest.length > 2) {
                answer(rest)
            } else {
                awaitingCommand = true
                beep()
                listener.onState(State.LISTENING, null)
                restartSoon(150)
            }
            return true
        }
        return false
    }

    private class Wake(val rest: String, val full: Boolean)

    /**
     * Первое слово фразы («Капри») — имя для вызова. Следом можно сказать команду
     * («Капри следующее») или остаток фразы («Капри ответ») и задать вопрос отдельно.
     */
    private fun parseWake(text: String): Wake? {
        val words = norm(settings.wakePhrase).split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return null
        val i = text.indexOf(words[0])
        if (i < 0) return null
        var rest = text.substring(i + words[0].length).trim()
        var full = words.size == 1
        if (words.size > 1) {
            val tail = words.drop(1).joinToString(" ")
            if (rest.startsWith(tail)) {
                rest = rest.removePrefix(tail).trim()
                full = true
            }
        }
        return Wake(rest, full)
    }

    // ---------------------------------------------------------------- ответ

    private fun answer(question: String) {
        busy = true
        recognizer?.cancel()
        listener.onState(State.THINKING, question)
        Answers.reply(context, settings, question) { text ->
            main.post { speak(text) }
        }
    }

    private fun speak(text: String) {
        if (!running) return
        listener.onState(State.SPEAKING, text)
        if (ttsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "capri-answer")
        } else {
            main.postDelayed({ finishAnswer() }, 3500)
        }
    }

    private fun finishAnswer() {
        if (!busy) return
        busy = false
        awaitingCommand = false
        listener.onState(State.WAKE, null)
        restartSoon(500)
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 60)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            main.postDelayed({ tg.release() }, 300)
        } catch (_: Exception) {
        }
    }
}
