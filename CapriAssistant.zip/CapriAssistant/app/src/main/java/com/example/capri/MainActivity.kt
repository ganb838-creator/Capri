package com.example.capri

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Главный экран: процент заряда, включение панели, настройки персонажа и раскраска. */
class MainActivity : Activity() {

    private lateinit var settings: Settings
    private lateinit var preview: CharacterView
    private lateinit var batteryText: TextView
    private lateinit var panelSwitch: Switch

    private val bg = 0xFF0B0B12.toInt()
    private val card = 0xFF15151F.toInt()

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val pct = if (level < 0) -1 else level * 100 / scale
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            batteryText.text = if (pct < 0) "Заряд: —" else "Заряд: $pct%" + if (charging) " ⚡" else ""
        }
    }

    // ------------------------------------------------------------ палитры

    private fun colors(vararg hex: String) = hex.map { Color.parseColor(it) }

    private val neon = colors("#00F0FF", "#FF2E93", "#FFE600", "#39FF14", "#B026FF", "#FF6A00", "#FFFFFF", "#FF2B2B")
    private val panels = colors("#0B0B12", "#101935", "#1E0B2E", "#2A0A12", "#0A2318", "#22222A", "#08262B", "#000000")
    private val hairs = colors("#FF2E93", "#00F0FF", "#FFFFFF", "#15151C", "#B026FF", "#2D6BFF", "#FF2B2B", "#C8CCD6")
    private val skins = colors("#FFE0C8", "#F2C6A0", "#D9A07A", "#B57B55", "#8A5A3C", "#5E3A26", "#E8EEF5", "#B8C7D9")
    private val outfits = colors("#2B2B44", "#15151C", "#4A1230", "#0F3A3F", "#3A2B0F", "#5A5A66", "#1F3D2B", "#6B1B1B")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(40))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(column)
        }
        setContentView(scroll)

        // Заголовок и персонаж.
        column.addView(text("Капри", 26f, bold = true, color = Color.WHITE))
        preview = CharacterView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(150), dp(150)).apply { topMargin = dp(8) }
        }
        column.addView(preview)
        batteryText = text("Заряд: —", 30f, bold = true, color = settings.accent)
        column.addView(batteryText)

        // Включение панели.
        panelSwitch = Switch(this).apply {
            text = "Панель сверху и голосовой помощник"
            setTextColor(Color.WHITE)
            setPadding(0, dp(16), 0, dp(8))
            setOnCheckedChangeListener { _, on -> if (on) startPanel() else stopPanel() }
        }
        column.addView(panelSwitch)
        column.addView(hint("Скажите «${settings.wakePhrase}», потом задайте вопрос. Тап по панели — слушать сразу, долгое нажатие — настройки."))
        column.addView(hint("Команды: «Капри открой МТС Музыка», «Капри следующее», «Капри прошлое», «Капри стоп», «Капри звонок» (ответить), «Капри отбой» (сбросить)."))

        // Разрешения.
        column.addView(section("Разрешения"))
        column.addView(button("Разрешить показ поверх других окон") { openOverlaySettings() })
        column.addView(button("Включить слежение за открытием приложений") {
            startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        column.addView(hint("Второе — по желанию: панель будет реагировать, когда вы открываете приложение. Содержимое экрана не читается."))

        // Персонаж.
        column.addView(section("Персонаж"))
        column.addView(label("Имя"))
        column.addView(edit(settings.name) { settings.name = it })
        column.addView(label("Фраза для вызова"))
        column.addView(edit(settings.wakePhrase) { settings.wakePhrase = it })

        // Раскраска.
        column.addView(section("Раскраска"))
        column.addView(label("Цвет панели"))
        column.addView(swatches(panels, settings.panelColor) { settings.panelColor = it })
        column.addView(label("Неон (глаза, рамка, заряд)"))
        column.addView(swatches(neon, settings.accent) {
            settings.accent = it
            batteryText.setTextColor(it)
        })
        column.addView(label("Волосы"))
        column.addView(swatches(hairs, settings.hair) { settings.hair = it })
        column.addView(label("Кожа"))
        column.addView(swatches(skins, settings.skin) { settings.skin = it })
        column.addView(label("Одежда"))
        column.addView(swatches(outfits, settings.outfit) { settings.outfit = it })

        column.addView(label("Положение панели сверху"))
        column.addView(SeekBar(this).apply {
            max = 80
            progress = settings.panelY
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) settings.panelY = p
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        refreshPreview()
        requestBasicPermissions()
    }

    override fun onStart() {
        super.onStart()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    override fun onStop() {
        unregisterReceiver(batteryReceiver)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        panelSwitch.setOnCheckedChangeListener(null)
        panelSwitch.isChecked = OverlayService.running
        panelSwitch.setOnCheckedChangeListener { _, on -> if (on) startPanel() else stopPanel() }
    }

    // ------------------------------------------------------------ действия

    private fun refreshPreview() {
        preview.skin = settings.skin
        preview.hair = settings.hair
        preview.outfit = settings.outfit
        preview.accent = settings.accent
    }

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestBasicPermissions() {
        val need = mutableListOf<String>()
        if (!hasMic()) need += Manifest.permission.RECORD_AUDIO
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            need += Manifest.permission.ANSWER_PHONE_CALLS
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun startPanel() {
        when {
            !AndroidSettings.canDrawOverlays(this) -> {
                panelSwitch.isChecked = false
                openOverlaySettings()
            }
            !hasMic() -> {
                panelSwitch.isChecked = false
                requestBasicPermissions()
            }
            else -> startForegroundService(Intent(this, OverlayService::class.java))
        }
    }

    private fun stopPanel() {
        stopService(Intent(this, OverlayService::class.java))
    }

    // ------------------------------------------------------------ элементы интерфейса

    private fun text(s: String, sp: Float, bold: Boolean = false, color: Int = Color.WHITE) =
        TextView(this).apply {
            text = s
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun hint(s: String) = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setTextColor(0xFF9A9AB0.toInt())
        setPadding(0, dp(2), 0, dp(8))
    }

    private fun section(s: String) = TextView(this).apply {
        text = s.uppercase()
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(0xFFFF2E93.toInt())
        setPadding(0, dp(24), 0, dp(6))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    private fun label(s: String) = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTextColor(Color.WHITE)
        setPadding(0, dp(10), 0, dp(4))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    private fun button(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            cornerRadius = dpf(14f)
            setColor(card)
            setStroke(dp(1), 0xFF00F0FF.toInt())
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) }
        setOnClickListener { onClick() }
    }

    private fun edit(initial: String, onChange: (String) -> Unit) = EditText(this).apply {
        setText(initial)
        setTextColor(Color.WHITE)
        setSingleLine()
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = onChange(s?.toString().orEmpty())
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
    }

    /** Ряд цветных кружков: тап по кружку сохраняет цвет и сразу меняет вид персонажа и панели. */
    private fun swatches(list: List<Int>, selected: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        val views = mutableListOf<View>()
        fun mark(current: Int) {
            list.forEachIndexed { i, c ->
                (views[i].background as GradientDrawable)
                    .setStroke(dp(if (c == current) 3 else 1), if (c == current) Color.WHITE else 0xFF555566.toInt())
            }
        }
        list.forEach { c ->
            val v = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                }
                layoutParams = LinearLayout.LayoutParams(0, dp(32), 1f).apply {
                    marginEnd = dp(6)
                }
                setOnClickListener {
                    onPick(c)
                    mark(c)
                    refreshPreview()
                }
            }
            views += v
            row.addView(v)
        }
        mark(selected)
        return row
    }
}
