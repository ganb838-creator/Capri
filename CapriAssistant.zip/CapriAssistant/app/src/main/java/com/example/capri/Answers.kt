package com.example.capri

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/** Ответы на голосовые запросы: время, дата, заряд, а всё остальное ищется в Википедии. */
object Answers {

    private val ru = Locale("ru", "RU")

    private val wikiPrefix = Regex(
        "^(что такое|что значит|кто такой|кто такая|кто такие|расскажи про|расскажи о|расскажи об|" +
            "объясни|найди|поищи|скажи что такое|что за)\\s+"
    )

    /** Вызывает [done] на фоновом потоке; вызывающий сам переводит результат на главный поток. */
    fun reply(context: Context, settings: Settings, query: String, done: (String) -> Unit) {
        val q = query.lowercase(ru).replace('ё', 'е').trim().trimEnd('.', '?', '!')
        Actions.handle(context, q)?.let {
            done(it)
            return
        }
        when {
            q.isEmpty() -> done("Я слушаю. Спросите что-нибудь.")

            q.contains("привет") || q.contains("здравствуй") ->
                done("Привет! Я ${settings.name}. Чем помочь?")

            q.contains("как тебя зовут") || q.contains("кто ты") ->
                done("Я ${settings.name}, ваш помощник на верхней панели.")

            q.contains("который час") || q.contains("сколько времени") || q.contains("время") ->
                done("Сейчас " + SimpleDateFormat("HH:mm", ru).format(Date()))

            q.contains("какое число") || q.contains("какой день") || q.contains("дата") ||
                q.contains("сегодня") ->
                done("Сегодня " + SimpleDateFormat("EEEE, d MMMM yyyy", ru).format(Date()))

            q.contains("заряд") || q.contains("батаре") || q.contains("процент") ->
                done(batteryText(context))

            q.contains("спасибо") -> done("Всегда пожалуйста!")

            else -> thread(name = "capri-wiki") {
                val topic = wikiPrefix.replace(q, "")
                done(wikipedia(topic) ?: "Не нашла ответ. Попросите так: «что такое» и тема.")
            }
        }
    }

    fun batteryPercent(context: Context): Int {
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (level < 0) -1 else level * 100 / scale
    }

    private fun batteryText(context: Context): String {
        val p = batteryPercent(context)
        return if (p < 0) "Не удалось узнать заряд." else "Заряд батареи $p процентов."
    }

    private fun get(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 6000
        c.setRequestProperty("User-Agent", "CapriAssistant/1.0 (Android)")
        if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
    } catch (e: Exception) {
        null
    }

    private fun wikipedia(topic: String): String? {
        if (topic.isBlank()) return null
        val enc = URLEncoder.encode(topic, "UTF-8")
        val search = get(
            "https://ru.wikipedia.org/w/api.php?action=opensearch&limit=1&format=json&search=$enc"
        ) ?: return "Нет подключения к интернету."
        val title = try {
            JSONArray(search).getJSONArray(1).optString(0, "")
        } catch (e: Exception) {
            ""
        }
        if (title.isBlank()) return null

        val titleEnc = URLEncoder.encode(title, "UTF-8").replace("+", "%20")
        val summary = get("https://ru.wikipedia.org/api/rest_v1/page/summary/$titleEnc") ?: return null
        val text = try {
            JSONObject(summary).optString("extract", "")
        } catch (e: Exception) {
            ""
        }
        if (text.isBlank()) return null
        return shorten(text)
    }

    /** Убираем скобки и оставляем первые два предложения. */
    private fun shorten(text: String): String {
        val clean = text.replace(Regex("\\([^)]*\\)"), "").replace(Regex("\\s+"), " ").trim()
        val parts = clean.split(Regex("(?<=[.!?])\\s+"))
        val out = parts.take(2).joinToString(" ")
        return if (out.length > 320) out.take(320).trimEnd() + "…" else out
    }
}
