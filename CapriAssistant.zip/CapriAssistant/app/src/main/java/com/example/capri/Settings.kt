package com.example.capri

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

/** Все настройки Капри: имя, фраза, цвета (раскраска), положение панели. */
class Settings(context: Context) {

    val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("capri", Context.MODE_PRIVATE)

    var name: String
        get() = prefs.getString("name", "Капри") ?: "Капри"
        set(v) = prefs.edit().putString("name", v.ifBlank { "Капри" }).apply()

    var wakePhrase: String
        get() = prefs.getString("wake", "Капри ответ") ?: "Капри ответ"
        set(v) = prefs.edit().putString("wake", v.ifBlank { "Капри ответ" }).apply()

    var panelColor: Int
        get() = prefs.getInt("panel", Color.parseColor("#0B0B12"))
        set(v) = prefs.edit().putInt("panel", v).apply()

    var accent: Int
        get() = prefs.getInt("accent", Color.parseColor("#00F0FF"))
        set(v) = prefs.edit().putInt("accent", v).apply()

    var hair: Int
        get() = prefs.getInt("hair", Color.parseColor("#FF2E93"))
        set(v) = prefs.edit().putInt("hair", v).apply()

    var skin: Int
        get() = prefs.getInt("skin", Color.parseColor("#F2C6A0"))
        set(v) = prefs.edit().putInt("skin", v).apply()

    var outfit: Int
        get() = prefs.getInt("outfit", Color.parseColor("#2B2B44"))
        set(v) = prefs.edit().putInt("outfit", v).apply()

    /** Отступ панели от верхнего края экрана, dp. */
    var panelY: Int
        get() = prefs.getInt("panelY", 10)
        set(v) = prefs.edit().putInt("panelY", v).apply()
}
