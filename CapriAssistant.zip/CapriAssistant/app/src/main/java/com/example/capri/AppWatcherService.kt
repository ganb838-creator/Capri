package com.example.capri

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Узнаёт, что пользователь открыл другое приложение, и сообщает панели.
 * Содержимое экрана не читается (canRetrieveWindowContent = false).
 */
class AppWatcherService : AccessibilityService() {

    private var lastPackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == lastPackage) return
        if (pkg == packageName || pkg == "com.android.systemui") return
        lastPackage = pkg
        Bus.onAppOpened?.invoke(pkg)
    }

    override fun onInterrupt() {}
}
