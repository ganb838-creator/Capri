package com.example.capri

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.telecom.TelecomManager
import android.view.KeyEvent
import java.util.Locale

/**
 * Команды-действия: открыть приложение, управлять музыкой/видео, ответить на звонок или сбросить его.
 * Вызывается из главного потока. Возвращает текст ответа или null, если это не команда-действие.
 */
object Actions {

    private val ru = Locale("ru", "RU")

    /** Как произносится -> как может называться в телефоне. */
    private val aliases = listOf(
        "ютуб" to "youtube",
        "телеграм" to "telegram",
        "ватсап" to "whatsapp",
        "вацап" to "whatsapp",
        "вотсап" to "whatsapp",
        "инстаграм" to "instagram",
        "гугл хром" to "chrome",
        "хром" to "chrome",
        "музыка" to "music",
        "карты" to "maps",
        "почта" to "mail",
        "камера" to "camera",
        "тикток" to "tiktok",
        "вк" to "vk",
        "спотифай" to "spotify"
    )

    private fun norm(s: String) = s.lowercase(ru).replace('ё', 'е')

    private fun key(s: String) = norm(s).filter { it.isLetterOrDigit() }

    fun handle(context: Context, q: String): String? {
        val words = norm(q).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return null
        val first = words[0]

        // Звонки.
        if (first == "звонок" || q.contains("возьми трубку") || q.contains("прими вызов") ||
            q.contains("ответь на звонок")
        ) return answerCall(context)
        if (first == "отбой" || first == "сбрось" || q.contains("положи трубку") ||
            q.contains("отклони")
        ) return rejectCall(context)

        // Музыка и видео.
        when {
            first in setOf("следующее", "следующий", "следующая", "дальше", "вперед", "переключи") ->
                return media(context, KeyEvent.KEYCODE_MEDIA_NEXT, "Следующее")
            first in setOf("прошлое", "прошлый", "прошлая", "предыдущее", "предыдущий", "предыдущая", "назад") ->
                return media(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Предыдущее")
            first in setOf("стоп", "пауза", "останови", "стой", "хватит") ->
                return media(context, KeyEvent.KEYCODE_MEDIA_PAUSE, "Пауза")
            first in setOf("продолжи", "продолжай", "играй", "воспроизведи") && words.size == 1 ->
                return media(context, KeyEvent.KEYCODE_MEDIA_PLAY, "Продолжаю")
        }

        // Открыть приложение.
        if (first in setOf("открой", "запусти", "включи", "открыть", "запустить") && words.size > 1) {
            val rest = words.drop(1).filter { it != "приложение" }.joinToString(" ")
            return openApp(context, rest)
        }
        return null
    }

    // ---------------------------------------------------------------- музыка и видео

    private fun media(context: Context, code: Int, answer: String): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return answer
    }

    // ---------------------------------------------------------------- звонки

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun answerCall(context: Context): String {
        if (context.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) !=
            PackageManager.PERMISSION_GRANTED
        ) return "Нужно разрешение на ответы на звонки. Дайте его в настройках приложения."
        return try {
            val tm = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.acceptRingingCall()
            "Отвечаю на звонок."
        } catch (e: Exception) {
            "Не получилось ответить на звонок."
        }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun rejectCall(context: Context): String {
        if (context.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) !=
            PackageManager.PERMISSION_GRANTED
        ) return "Нужно разрешение на управление звонками. Дайте его в настройках приложения."
        if (Build.VERSION.SDK_INT < 28) return "На этой версии Android я не умею сбрасывать звонки."
        return try {
            val tm = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            if (tm.endCall()) "Звонок сброшен." else "Сейчас нет звонка."
        } catch (e: Exception) {
            "Не получилось сбросить звонок."
        }
    }

    // ---------------------------------------------------------------- приложения

    private fun openApp(context: Context, spoken: String): String {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)

        val want = key(spoken)
        if (want.isEmpty()) return "Какое приложение открыть?"
        val candidates = mutableListOf(want)
        for ((from, to) in aliases) {
            val f = key(from)
            if (want.contains(f)) candidates += want.replace(f, key(to))
        }

        var bestScore = 0
        var bestPkg: String? = null
        var bestLabel = ""
        for (info in apps) {
            val label = info.loadLabel(pm).toString()
            val lk = key(label)
            if (lk.isEmpty()) continue
            for (c in candidates) {
                val score = when {
                    lk == c -> 100
                    lk.contains(c) -> 80
                    lk.length >= 3 && c.contains(lk) -> 60
                    else -> 0
                }
                if (score > bestScore) {
                    bestScore = score
                    bestPkg = info.activityInfo.packageName
                    bestLabel = label
                }
            }
        }

        val pkg = bestPkg ?: return "Не нашла приложение «$spoken»."
        val intent = pm.getLaunchIntentForPackage(pkg)
            ?: return "Не получилось открыть «$bestLabel»."
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            "Открываю $bestLabel."
        } catch (e: Exception) {
            "Не получилось открыть «$bestLabel»."
        }
    }
}
