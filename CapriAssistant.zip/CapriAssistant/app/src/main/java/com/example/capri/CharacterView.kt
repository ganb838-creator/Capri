package com.example.capri

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/**
 * Оригинальный киберпанк-персонаж, нарисованный кодом.
 * Все цвета настраиваются (раскраска): кожа, волосы, одежда, неон.
 */
class CharacterView(context: Context) : View(context) {

    enum class Mood { IDLE, LISTENING, TALKING, HAPPY }

    var skin: Int = 0xFFF2C6A0.toInt()
        set(v) { field = v; invalidate() }
    var hair: Int = 0xFFFF2E93.toInt()
        set(v) { field = v; invalidate() }
    var outfit: Int = 0xFF2B2B44.toInt()
        set(v) { field = v; invalidate() }
    var accent: Int = 0xFF00F0FF.toInt()
        set(v) { field = v; invalidate() }
    var mood: Mood = Mood.IDLE
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var t = 0f

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3000
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    /** Короткая «подпрыгивающая» реакция на касание или событие. */
    fun bounce() {
        animate().cancel()
        animate().scaleX(1.25f).scaleY(1.25f).setDuration(110).withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(160).start()
        }.start()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // Кольцо при прослушивании.
        if (mood == Mood.LISTENING) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = w * 0.06f
            p.color = accent
            p.alpha = (120 + 120 * abs(sin(t * Math.PI * 2))).toInt().coerceIn(0, 255)
            canvas.drawCircle(w / 2, h / 2, w * 0.48f, p)
            p.alpha = 255
        }
        p.style = Paint.Style.FILL

        // Одежда (плечи).
        p.color = outfit
        canvas.drawRoundRect(RectF(w * 0.12f, h * 0.80f, w * 0.88f, h * 1.15f), w * 0.2f, w * 0.2f, p)
        // Неоновая полоска на воротнике.
        p.color = accent
        canvas.drawRect(w * 0.40f, h * 0.84f, w * 0.60f, h * 0.87f, p)

        // Волосы сзади.
        p.color = hair
        canvas.drawRoundRect(RectF(w * 0.12f, h * 0.06f, w * 0.88f, h * 0.92f), w * 0.4f, w * 0.4f, p)

        // Лицо.
        p.color = skin
        canvas.drawOval(RectF(w * 0.24f, h * 0.17f, w * 0.76f, h * 0.84f), p)

        // Чёлка.
        p.color = hair
        path.reset()
        path.moveTo(w * 0.20f, h * 0.45f)
        path.quadTo(w * 0.22f, h * 0.08f, w * 0.52f, h * 0.10f)
        path.quadTo(w * 0.80f, h * 0.10f, w * 0.80f, h * 0.45f)
        path.quadTo(w * 0.62f, h * 0.22f, w * 0.40f, h * 0.34f)
        path.quadTo(w * 0.30f, h * 0.38f, w * 0.20f, h * 0.45f)
        path.close()
        canvas.drawPath(path, p)

        // Глаза (моргание в конце цикла).
        val blink = t in 0.92f..0.97f
        val eyeH = if (blink) h * 0.012f else h * 0.055f
        val eyeY = h * 0.52f
        for (cx in floatArrayOf(w * 0.39f, w * 0.61f)) {
            // Неоновое свечение.
            p.color = accent
            p.alpha = 70
            canvas.drawOval(RectF(cx - w * 0.095f, eyeY - eyeH * 1.6f, cx + w * 0.095f, eyeY + eyeH * 1.6f), p)
            p.alpha = 255
            canvas.drawOval(RectF(cx - w * 0.06f, eyeY - eyeH, cx + w * 0.06f, eyeY + eyeH), p)
            p.color = 0xFF0B0B12.toInt()
            canvas.drawCircle(cx, eyeY, w * 0.018f, p)
        }

        // Киберлиния на щеке.
        p.color = accent
        p.style = Paint.Style.STROKE
        p.strokeWidth = w * 0.02f
        canvas.drawLine(w * 0.66f, h * 0.58f, w * 0.72f, h * 0.70f, p)
        canvas.drawLine(w * 0.72f, h * 0.70f, w * 0.68f, h * 0.74f, p)
        p.style = Paint.Style.FILL

        // Рот.
        val mouthY = h * 0.70f
        p.color = 0xFF7A1F3A.toInt()
        when (mood) {
            Mood.TALKING -> {
                val open = h * (0.015f + 0.035f * abs(sin(t * Math.PI * 2 * 5)).toFloat())
                canvas.drawOval(RectF(w * 0.44f, mouthY - open, w * 0.56f, mouthY + open), p)
            }
            Mood.HAPPY -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = w * 0.025f
                path.reset()
                path.moveTo(w * 0.42f, mouthY - h * 0.01f)
                path.quadTo(w * 0.50f, mouthY + h * 0.07f, w * 0.58f, mouthY - h * 0.01f)
                canvas.drawPath(path, p)
                p.style = Paint.Style.FILL
            }
            else -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = w * 0.022f
                canvas.drawLine(w * 0.45f, mouthY, w * 0.55f, mouthY, p)
                p.style = Paint.Style.FILL
            }
        }
    }
}
